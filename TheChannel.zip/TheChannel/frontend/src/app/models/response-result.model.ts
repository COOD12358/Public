export interface ResponseResult {
  success: boolean;
}